SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"


REPLACE="
"

print_modname() {
  ui_print "______________________________________________________"
  ui_print "                  thermod GALANG X FAJAR (BETA)                     "
  echo -n "- Date&Time: "
date "+%c"
sleep 2
ui_print "check information device"
sleep 2
ui_print "° Device           : $(getprop ro.product.name) "
sleep 0.5
ui_print "° Code name        : $(getprop ro.product.board) "
sleep 0.5
ui_print "° Android version  : $(getprop ro.build.version.release) "
sleep 0.5
ui_print "° SDK              : $(getprop ro.build.version.sdk) "
sleep 0.5
ui_print "° CPU_ABI          : $(getprop ro.product.cpu.abi) "
sleep 0.5
ui_print "° Hardware         : $(getprop ro.boot.hardware) "
sleep 0.5
ui_print "° Rom              : $(getprop ro.build.display.id) "
sleep 0.5
ui_print "° Fingerprint     : $(getprop ro.vendor.build.fingerprint) "
sleep 0.5
ui_print "° Kernel          : $(uname -r) "
sleep 0.5
ui_print "  flashing  "
sleep 2
ui_print "  pacth lib.so   "
sleep 2
ui_print "   wait for pacth kernel  "
sleep 1
sleep 1
sleep 1
ui_print "° detected kernel : $(uname -r)"
sleep 1

busybox sleep 1
  ui_print "      Install script           "
sleep 1
busybox sleep 1
  ui_print "-------------------------------------------------- "
  ui_print "           Created by : G A L A N G    "
  ui_print "-------------------------------------------------- "
sleep 1
  ui_print "  pacth kernel      : $(uname -r) "
sleep 1
  busybox sleep 1
  ui_print "                 Loading..."
sleep 1
  busybox sleep 1
  ui_print "                 Installing tweaks..."
sleep 1
  ui_print "                 Wait.."
sleep 4
  busybox sleep 1
sleep 1
  ui_print "  done to pacth : $(uname -r) "
  busybox sleep 1
sleep 1
ui_print "installing Zram 5 GB "
sleep 2
ui_print " wait..."
sleep 3
ui_print " removing cache "
sleep 2
  ui_print "please reboot"
}


# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/system/bin/P0 0 0 0755 0755
  set_perm $MODPATH/system/bin/P1 0 0 0755 0755
  

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code
CHECK1() {
D=$(getprop ro.product.device 2>/dev/null)
P=$(getprop ro.build.product 2>/dev/null)
VD=$(getprop ro.product.vendor.device 2>/dev/null)
VP=$(getprop ro.vendor.product.device 2>/dev/null)
DN=whyred

case "$DN" in
 "$D"|"$P"|"$VD"|"$VP")
  why=1
 ;;
 *)
  why=0
 ;;
esac

sleep $TIME

if [ "$why" == "0" ]; then
 ui_print "* Snapdragon only.!!!"
 abort "* Err Code1 : Installation Not Approved , Aborting !!! *"
elif [ "$why" == "1" ]; then
 ui_print "* Installation Approved Level 1 , Snapdragon detected *"
fi;
}

CHECK2() {
if [ -e $SBIN/disable_thermal-throttle/disable ]; then
 Conf=1
elif [ -d $SBIN/disable_thermal-throttle ]; then
 Conf=1
elif [ -e $SBIN/FThermalXWH/disable ]; then
 Conf=1
elif [ -d $SBIN/FThermalXWH ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv1/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv1 ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv2/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv2 ]; then
 Conf=1
elif [ -e $SBIN/neothermalwhyred/disable ]; then
 Conf=1
elif [ -d $SBIN/neothermalwhyred ]; then
 Conf=1
elif [ -e $SBIN/uni-thermal-mod-whyred/disable ]; then
 Conf=1
elif [ -d $SBIN/uni-thermal-mod-whyred ]; then
 Conf=1
else
 Conf=0
fi;

sleep $TIME

if [ "Conf" == "1" ]; then
 ui_print "* No Thermal Detected..!!!"
 sleep 1
 abort "* Err Code : Installation Not Approved  , Aborting !!! *"
 sleep 1
elif [ "$Conf" == "0" ]; then
sleep 1
 ui_print "* Installation Approved Level  , Thermal Detected *"
 sleep 1
fi;
}

#CHECK1
CHECK2
#remove cache
rm -rf /cache/dalvik-cache